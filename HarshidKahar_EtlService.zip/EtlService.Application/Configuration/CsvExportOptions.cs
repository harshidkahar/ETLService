﻿
namespace EtlService.Application.Configuration;

public class CsvExportOptions
{
    public string ExportPath { get; set; } = string.Empty;
}
