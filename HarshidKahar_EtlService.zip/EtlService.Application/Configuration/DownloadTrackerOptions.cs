﻿
namespace EtlService.Application.Configuration;

public class DownloadTrackerOptions
{
    public string LogFilePath { get; set; } = string.Empty;
}
